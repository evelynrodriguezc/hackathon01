import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const LoginForm = () => {
  const [userLogin, setUserLogin] = useState({ username: "", password: "" });
  const [adminLogin, setAdminLogin] = useState({ username: "", password: "" });
  const [userError, setUserError] = useState("");
  const [adminError, setAdminError] = useState("");
  const navigate = useNavigate();

  // Función para manejar el login de usuarios
  const handleUserLogin = async (e) => {
    e.preventDefault();

    try {
      // Reemplazar con llamada a API para autenticar usuario
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userLogin),
      });

      if (response.ok) {
        navigate("/reservar"); // Redirige a la página de reservas
      } else {
        setUserError("Usuario o contraseña incorrecta.");
      }
    } catch (err) {
      setUserError("Error al conectar con el servidor.");
    }
  };

  // Función para manejar el login de administrador
  const handleAdminLogin = (e) => {
    e.preventDefault();

    const { username, password } = adminLogin;
    if (username === "adminnido" && password === "Salasnido!") {
      navigate("/admin"); // Redirige al panel de administración
    } else {
      setAdminError("Usuario o contraseña incorrecta.");
    }
  };

  return (
    <div className="login-container">
      {/* Login de Usuarios */}
      <div className="login-column">
        <form className="login-form" onSubmit={handleUserLogin}>
          <h1>Login Usuarios</h1>
          <div className="input-box">
            <input
              type="text"
              placeholder="Username"
              value={userLogin.username}
              onChange={(e) =>
                setUserLogin({ ...userLogin, username: e.target.value })
              }
              required
            />
          </div>
          <div className="input-box">
            <input
              type="password"
              placeholder="Password"
              value={userLogin.password}
              onChange={(e) =>
                setUserLogin({ ...userLogin, password: e.target.value })
              }
              required
            />
          </div>
          
          <button type="submit">Ingresar</button>
          <div className="registrarse">
            
            <p>
              ¿No tienes cuenta? <a href="/registro">Registrarse</a>
            </p>
          </div>
          {userError && <p style={{ color: "red", marginTop: "10px" }}>{userError}</p>}
        </form>
      </div>

      {/* Login de Administrador */}
      <div className="login-column">
        <form className="login-form" onSubmit={handleAdminLogin}>
          <h1>Login Administrador</h1>
          <div className="input-box">
            <input
              type="text"
              placeholder="Username"
              value={adminLogin.username}
              onChange={(e) =>
                setAdminLogin({ ...adminLogin, username: e.target.value })
              }
              required
            />
          </div>
          <div className="input-box">
            <input
              type="password"
              placeholder="Password"
              value={adminLogin.password}
              onChange={(e) =>
                setAdminLogin({ ...adminLogin, password: e.target.value })
              }
              required
            />
          </div>
          <button type="submit">Ingresar</button>
          {adminError && (
            <p style={{ color: "red", marginTop: "10px" }}>{adminError}</p>
          )}
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
