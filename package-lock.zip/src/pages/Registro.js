import React from "react";


const Registro = () => {
    return (
        <div className="registro-container">
            <form className="registro-form">
                <h1>Registro de Usuario</h1>
                <div className="input-box">
                    <input type="text" placeholder="Nombre" required />
                </div>
                <div className="input-box">
                    <input type="text" placeholder="Apellido" required />
                </div>
                <div className="input-box">
                    <input type="text" placeholder="Teléfono" required />
                </div>
                <div className="input-box">
                    <input type="text" placeholder="Documento" required />
                </div>
                <div className="input-box">
                    <input type="email" placeholder="Correo (Usuario)" required />
                </div>
                <div className="input-box">
                    <input type="password" placeholder="Contraseña" required />
                </div>
                <button type="submit">Registrarse</button>
            </form>
        </div>
    );
};

export default Registro;
