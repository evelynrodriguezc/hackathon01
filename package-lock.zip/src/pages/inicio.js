import React from "react";
import { Carousel, Button } from "react-bootstrap";
import { Link } from "react-router-dom"; // Importar Link

const Inicio = () => {
  return (
    <div>
      {/* Carousel centrado */}
      <div className="carousel-container">
        <Carousel fade>
          <Carousel.Item>
            <img
              className="d-block w-100 carousel-img"
              src="images/imagen1.png"
              alt="Primera imagen"
            />
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100 carousel-img"
              src="images/imagen2.png"
              alt="Segunda imagen"
            />
          </Carousel.Item>
        </Carousel>
      </div>

      {/* Sección "Conócenos" */}
      <section id="conocenos" className="section-content">
        <div className="container">
          <h2 className="section-title">¿Quiénes Somos?</h2>
          <p className="section-text">
            Nos especializamos en ofrecer espacios de alta calidad para reuniones
            empresariales y eventos exclusivos.
          </p>

          <h2 className="section-title">¿Qué Ofrecemos?</h2>
          <p className="section-text">
            Ofrecemos habitaciones especialmente diseñadas para satisfacer las
            necesidades de socios de Zonamérica, equipadas con tecnología de
            última generación y servicios de primera clase.
          </p>

          {/* Botón "Más información" */}
          <div className="d-flex justify-content-center mt-4">
            <Link to="/contacto"> {/* Enlace al contacto */}
              <Button variant="outline-light" className="btn-main">
                Contactanos
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Inicio;
